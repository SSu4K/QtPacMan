#ifndef PATHFINDING_SPRITE_H
#define PATHFINDING_SPRITE_H


class pathfinding_sprite : public MovingSprite
{
public:
    pathfinding_sprite();
};

#endif // PATHFINDING_SPRITE_H
